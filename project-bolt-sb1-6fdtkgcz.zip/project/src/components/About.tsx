import React, { useEffect, useRef } from 'react';
import { 
  Target, 
  Eye, 
  Award, 
  Users, 
  Clock, 
  Globe,
  CheckCircle,
  TrendingUp,
  Shield,
  Heart,
  Zap,
  MapPin
} from 'lucide-react';

const About = () => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in-up');
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = sectionRef.current?.querySelectorAll('.scroll-animate');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const stats = [
    { icon: Clock, label: 'Years Experience', value: '17+' },
    { icon: Globe, label: 'APAC Markets', value: '10+' },
    { icon: Award, label: 'ISO Certified', value: '27001:2022' },
    { icon: Users, label: 'SME Clients', value: '500+' }
  ];

  const values = [
    {
      icon: Shield,
      title: 'Security First',
      description: 'Everything we do is designed with compliance, resilience, and protection in mind.'
    },
    {
      icon: Heart,
      title: 'Customer Partnership',
      description: 'We believe in long-term relationships built on trust, transparency, and results.'
    },
    {
      icon: Zap,
      title: 'Agility & Growth',
      description: 'We move fast, adapt quickly, and scale responsibly with your business.'
    },
    {
      icon: MapPin,
      title: 'Regional Depth, Global Thinking',
      description: 'With local insight and global standards, we deliver tailored solutions for complex markets.'
    }
  ];

  return (
    <section id="about" ref={sectionRef} className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8 scroll-animate opacity-0 translate-x-[-50px] transition-all duration-700">
            <div className="space-y-4">
              <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-semibold">
                <Users className="h-4 w-4" />
                <span>A Trusted Technology Partner in APAC</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900">
                About Nexus Aurora
              </h2>
              <p className="text-xl text-gray-600 leading-relaxed">
                Nexus Aurora is a company of Pioneer Infotech Singapore, with over 17 years of proven experience in delivering high-quality Managed Services, Cybersecurity Solutions, and IT Consulting across Singapore and the broader ASEAN region.
              </p>
            </div>

            <div className="space-y-4">
              <p className="text-gray-600 leading-relaxed">
                With a strong foundation built on trust, technical excellence, and customer-centricity, Nexus Aurora was formed to focus on expanding Pioneer Infotech's technology marketing, consulting, and risk advisory capabilities into new markets—including Malaysia.
              </p>
              <p className="text-gray-600 leading-relaxed">
                Since 2008, Pioneer Infotech has delivered trusted Managed IT Services to SME clients across diverse sectors in banking, shipping, retail, logistics and enterprise operations. The company is ISO/IEC 27001:2022 certified, reflecting its deep commitment to information security and regulatory compliance.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => {
                const IconComponent = stat.icon;
                return (
                  <div key={index} className="text-center p-3 sm:p-6 bg-white rounded-xl shadow-sm">
                    <IconComponent className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                    <div className="text-xl sm:text-3xl font-bold text-gray-900 mb-1 break-words">{stat.value}</div>
                    <div className="text-gray-600 text-xs sm:text-sm leading-tight">{stat.label}</div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="space-y-8 scroll-animate opacity-0 translate-x-[50px] transition-all duration-700 delay-300">
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Our Heritage: Pioneer Infotech Singapore</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                Since 2008, Pioneer Infotech has delivered trusted Managed IT Services to SME clients across diverse sectors. With a robust service framework and a skilled regional team, Pioneer Infotech continues to drive operational efficiency, IT resilience, and compliance readiness for its clients.
              </p>
              <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-6 text-white">
                <h4 className="text-lg font-semibold mb-2">The Vision Behind Nexus Aurora</h4>
                <p className="text-blue-100">
                  Nexus Aurora was established to take our expertise further—focusing on Technology Market Development, Cyber Security Risk Assessment, Project Consulting & Implementation, and Managed IT Services tailored to SMBs and mid-sized enterprises.
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-2xl font-bold text-gray-900">Our Core Values</h3>
              <div className="space-y-4">
                {values.map((value, index) => {
                  const IconComponent = value.icon;
                  return (
                    <div key={index} className="flex space-x-4 bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                      <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <IconComponent className="h-6 w-6 text-blue-600" />
                      </div>
                      <div className="space-y-1">
                        <h4 className="font-semibold text-gray-900">{value.title}</h4>
                        <p className="text-gray-600 text-sm leading-relaxed">{value.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;