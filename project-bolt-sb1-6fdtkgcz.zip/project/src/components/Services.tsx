import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { 
  Globe, 
  Smartphone, 
  Cloud, 
  Target,
  Users, 
  Database, 
  Shield,
  Code,
  BarChart3,
  ArrowRight
} from 'lucide-react';

const Services = () => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in-up');
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = sectionRef.current?.querySelectorAll('.scroll-animate');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const services = [
    {
      icon: Users,
      title: 'IT Consultancy Services',
      description: 'Engaging an IT consultancy for a new hotel can help ensure that the right technology is in place to meet the needs of the guests while also helping to maximize efficiency and minimize costs. With the right technology and expertise in place, hotels can provide an enhanced customer experience and stay ahead of the competition.',
      features: ['Concept and Discovery', 'Design and Development', 'System and Vendor Review', 'Project Construction']
    },
    {
      icon: Globe,
      title: 'Web Development',
      description: 'Custom websites and web applications built with cutting-edge technologies for optimal performance and user experience.',
      features: ['Responsive Design', 'SEO Optimized', 'Fast Loading', 'Cross-browser Compatible']
    },
    {
      icon: Smartphone,
      title: 'Mobile App Development',
      description: 'Native and cross-platform mobile applications that engage users and drive business growth.',
      features: ['iOS & Android', 'React Native', 'Flutter', 'App Store Optimization']
    },
    {
      icon: Cloud,
      title: 'Cloud Hosting Services',
      description: 'We provide your business with the domain, website, and email hosting it needs. Solutions include a range of services, including basic web hosting for individuals and entrepreneurs, email, e-commerce, VPS server, and dedicated server hosting.',
      features: ['Shared Hosting', 'Dedicated Servers', 'Webhosting', 'Email Services', 'Backup & Disaster Recovery']
    },
    {
      icon: Database,
      title: 'System Servers',
      description: 'System solutions are the foundation to any company, with a roadmap for stability and scalability as key components to the system. Our consulting approach is based on lower TCO design for our clients.',
      features: ['Server Consolidation', 'Microsoft Solution', 'Backup Solution', 'Server and Server Integration', 'Virtualization Solution']
    },
    {
      icon: Shield,
      title: 'Cybersecurity',
      description: 'Comprehensive security solutions to protect your business from evolving cyber threats.',
      features: ['Security Audits', 'Penetration Testing', 'Compliance', 'Incident Response']
    }
  ];

  return (
    <section id="services" ref={sectionRef} className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16 scroll-animate opacity-0 translate-y-8 transition-all duration-700">
          <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-semibold">
            <Code className="h-4 w-4" />
            <span>Our Services</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900">
            Comprehensive IT Solutions
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We offer a full spectrum of technology services to help your business thrive in the digital landscape
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div
                key={index}
                className="group bg-white border border-gray-200 rounded-2xl p-8 hover:shadow-xl transition-all duration-300 hover:border-blue-200 hover:-translate-y-2 scroll-animate opacity-0 translate-y-8"
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="space-y-6">
                  <div className="h-16 w-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <IconComponent className="h-8 w-8 text-white" />
                  </div>
                  
                  <div className="space-y-3">
                    <h3 className="text-2xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors">
                      {service.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      {service.description}
                    </p>
                  </div>

                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center space-x-2 text-sm text-gray-600">
                        <div className="h-1.5 w-1.5 bg-blue-500 rounded-full"></div>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {service.title === 'IT Consultancy Services' ? (
                    <Link 
                      to="/it-consultancy"
                      className="group/btn inline-flex items-center space-x-2 text-blue-600 font-semibold hover:text-blue-700 transition-colors"
                    >
                      <span>Learn More</span>
                      <ArrowRight className="h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                    </Link>
                  ) : service.title === 'Web Development' ? (
                    <Link 
                     to="/web-development-process"
                      className="group/btn inline-flex items-center space-x-2 text-blue-600 font-semibold hover:text-blue-700 transition-colors"
                    >
                      <span>Learn More</span>
                      <ArrowRight className="h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                    </Link>
                  ) : service.title === 'Cybersecurity' ? (
                    <Link 
                      to="/cybersecurity"
                      className="group/btn inline-flex items-center space-x-2 text-blue-600 font-semibold hover:text-blue-700 transition-colors"
                    >
                      <span>Learn More</span>
                      <ArrowRight className="h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                    </Link>
                  ) : service.title === 'Cloud Hosting Services' ? (
                    <Link 
                      to="/cloud-hosting"
                      className="group/btn inline-flex items-center space-x-2 text-blue-600 font-semibold hover:text-blue-700 transition-colors"
                    >
                      <span>Learn More</span>
                      <ArrowRight className="h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                    </Link>
                  ) : service.title === 'System Servers' ? (
                    <Link 
                      to="/system-servers"
                      className="group/btn inline-flex items-center space-x-2 text-blue-600 font-semibold hover:text-blue-700 transition-colors"
                    >
                      <span>Learn More</span>
                      <ArrowRight className="h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                    </Link>
                  ) : service.title === 'Mobile App Development' ? (
                    <Link 
                      to="/mobile-app-development"
                      className="group/btn inline-flex items-center space-x-2 text-blue-600 font-semibold hover:text-blue-700 transition-colors"
                    >
                      <span>Learn More</span>
                      <ArrowRight className="h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                    </Link>
                  ) : (
                    <button className="group/btn inline-flex items-center space-x-2 text-blue-600 font-semibold hover:text-blue-700 transition-colors">
                      <span>Learn More</span>
                      <ArrowRight className="h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Services;
