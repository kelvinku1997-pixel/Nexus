import React from 'react';
import { useLocation } from 'react-router-dom';
import { 
  Code, 
  Zap, 
  Layers, 
  Palette,
  Database,
  Cloud,
  Shield,
  CheckCircle,
  ArrowRight,
  Monitor,
  Smartphone,
  Globe,
  Settings,
  Search
} from 'lucide-react';

const WebDevelopmentProcess = () => {
  const location = useLocation();

  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  const processSteps = [
    {
      title: 'Discovery & Planning',
      description: 'We start by understanding your business goals, target audience, and technical requirements. Our team conducts thorough research to create a comprehensive project roadmap.',
      icon: Search,
      color: 'from-blue-500 to-blue-600'
    },
    {
      title: 'Design & Prototyping',
      description: 'Using modern design tools, we create wireframes and interactive prototypes that visualize your website before development begins.',
      icon: Palette,
      color: 'from-purple-500 to-purple-600'
    },
    {
      title: 'Development with Nexus Aurora',
      description: 'We leverage Nexus Aurora, a cutting-edge development platform, to rapidly build and iterate on your website with real-time collaboration and instant previews.',
      icon: Zap,
      color: 'from-yellow-500 to-orange-500'
    },
    {
      title: 'Testing & Optimization',
      description: 'Comprehensive testing across all devices and browsers ensures your website performs flawlessly. We optimize for speed, SEO, and user experience.',
      icon: Shield,
      color: 'from-green-500 to-green-600'
    },
    {
      title: 'Launch & Support',
      description: 'We handle the deployment process and provide ongoing support to ensure your website continues to perform at its best.',
      icon: CheckCircle,
      color: 'from-indigo-500 to-indigo-600'
    }
  ];

  const technologies = [
    {
      category: 'Development Platform',
      tools: [
        { name: 'Nexus Aurora', description: 'Advanced development platform for rapid prototyping and deployment' },
        { name: 'Vite', description: 'Lightning-fast build tool for modern web development' },
        { name: 'WebContainer', description: 'Browser-based development environment' }
      ]
    },
    {
      category: 'Frontend Technologies',
      tools: [
        { name: 'React', description: 'Modern JavaScript library for building user interfaces' },
        { name: 'TypeScript', description: 'Type-safe JavaScript for better code quality' },
        { name: 'Tailwind CSS', description: 'Utility-first CSS framework for rapid styling' }
      ]
    },
    {
      category: 'Backend & Database',
      tools: [
        { name: 'Node.js', description: 'JavaScript runtime for server-side development' },
        { name: 'Supabase', description: 'Open-source Firebase alternative with PostgreSQL' },
        { name: 'PostgreSQL', description: 'Powerful, open-source relational database' }
      ]
    },
    {
      category: 'Deployment & Hosting',
      tools: [
        { name: 'Vercel', description: 'Platform for frontend frameworks and static sites' },
        { name: 'Netlify', description: 'Modern web development platform' },
        { name: 'AWS', description: 'Cloud computing services for scalable hosting' }
      ]
    }
  ];

  const features = [
    {
      icon: Monitor,
      title: 'Responsive Design',
      description: 'Every website we build looks perfect on desktop, tablet, and mobile devices'
    },
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Optimized for speed with modern build tools and performance best practices'
    },
    {
      icon: Shield,
      title: 'Secure & Reliable',
      description: 'Built with security in mind using industry-standard practices'
    },
    {
      icon: Globe,
      title: 'SEO Optimized',
      description: 'Search engine friendly structure and metadata for better visibility'
    }
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6">
            <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-semibold">
              <Code className="h-4 w-4" />
              <span>Our Development Process</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6">How We Build Your Website</h1>
            <p className="text-xl text-blue-100 max-w-4xl mx-auto leading-relaxed">
              Discover our streamlined web development process using cutting-edge technologies like Nexus Aurora
              to deliver exceptional websites faster than traditional methods.
            </p>
          </div>
        </div>
      </div>

      {/* Process Steps */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our 5-Step Development Process</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From concept to launch, we follow a proven methodology that ensures quality results and client satisfaction
            </p>
          </div>

          <div className="space-y-12">
            {processSteps.map((step, index) => {
              const IconComponent = step.icon;
              return (
                <div key={index} className="flex items-start space-x-8">
                  <div className="flex-shrink-0">
                    <div className={`h-20 w-20 bg-gradient-to-br ${step.color} rounded-2xl flex items-center justify-center shadow-lg`}>
                      <IconComponent className="h-10 w-10 text-white" />
                    </div>
                  </div>
                  <div className="flex-1 bg-slate-50 rounded-2xl p-8">
                    <div className="flex items-center space-x-3 mb-4">
                      <h3 className="text-2xl font-bold text-gray-900">{step.title}</h3>
                    </div>
                    <p className="text-gray-600 leading-relaxed text-lg">
                      {step.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Bolt.new Spotlight */}
      <section className="py-20 bg-gradient-to-r from-yellow-50 to-orange-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-6">
              <div className="inline-flex items-center space-x-2 bg-yellow-200 text-yellow-800 px-4 py-2 rounded-full text-sm font-semibold">
                <Zap className="h-4 w-4" />
                <span>Powered by Nexus Aurora</span>
              </div>
              <h2 className="text-4xl font-bold text-gray-900">
                Revolutionary Development with Nexus Aurora
              </h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  We use Nexus Aurora, an AI-powered development platform that revolutionizes how we build websites. 
                  This cutting-edge tool allows us to create, iterate, and deploy websites faster than ever before.
                </p>
                <p>
                  With Nexus Aurora real-time collaboration features and instant preview capabilities, we can show you 
                  your website as it's being built, making the development process more transparent and efficient.
                </p>
              </div>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="text-gray-700">Real-time development and preview</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="text-gray-700">AI-assisted code generation</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="text-gray-700">Instant deployment capabilities</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="text-gray-700">Collaborative development environment</span>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-white rounded-2xl p-8 shadow-2xl">
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="h-3 w-3 bg-red-500 rounded-full"></div>
                    <div className="h-3 w-3 bg-yellow-500 rounded-full"></div>
                    <div className="h-3 w-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm text-gray-500 ml-4">Nexus Aurora - Development Platform</span>
                  </div>
                  <div className="bg-gray-900 rounded-lg p-4 text-green-400 font-mono text-sm">
                    <div className="space-y-2">
                      <div>$ Nexus Aurora create website --template=react</div>
                      <div className="text-gray-500">✓ Creating project structure...</div>
                      <div className="text-gray-500">✓ Installing dependencies...</div>
                      <div className="text-gray-500">✓ Setting up development server...</div>
                      <div className="text-blue-400">🚀 Your website is ready!</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Technologies Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Technologies We Use</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We leverage the latest technologies and tools to build modern, scalable, and maintainable websites
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {technologies.map((category, index) => (
              <div key={index} className="bg-slate-50 rounded-2xl p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">{category.category}</h3>
                <div className="space-y-4">
                  {category.tools.map((tool, toolIndex) => (
                    <div key={toolIndex} className="bg-white rounded-lg p-4 border border-gray-200">
                      <h4 className="font-semibold text-gray-900 mb-2">{tool.name}</h4>
                      <p className="text-gray-600 text-sm">{tool.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">What You Get</h2>
            <p className="text-xl text-gray-600">
              Every website we build includes these essential features
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <div key={index} className="text-center p-6 bg-white rounded-xl shadow-sm hover:shadow-lg transition-shadow">
                  <div className="h-16 w-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-8">
            <h3 className="text-4xl font-bold text-white">
              Ready to Start Your Web Project?
            </h3>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Experience the power of modern web development with our streamlined process and cutting-edge tools.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-white text-blue-600 px-8 py-4 rounded-full font-semibold hover:bg-blue-50 transition-colors flex items-center justify-center space-x-2">
                <span>Start Your Project</span>
                <ArrowRight className="h-5 w-5" />
              </button>
              <button className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition-colors">
                View Our Portfolio
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default WebDevelopmentProcess;