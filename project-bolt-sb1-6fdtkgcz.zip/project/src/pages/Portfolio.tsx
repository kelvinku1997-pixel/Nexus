import React from 'react';
import PortfolioComponent from '../components/Portfolio';

const Portfolio = () => {
  return (
    <div className="pt-16">
      <div className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">Our Portfolio</h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Explore our successful projects and see how we've helped businesses transform digitally
          </p>
        </div>
      </div>
      <PortfolioComponent />
    </div>
  );
};

export default Portfolio;