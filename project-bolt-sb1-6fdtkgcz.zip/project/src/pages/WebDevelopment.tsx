import React from 'react';
import { useLocation } from 'react-router-dom';
import { 
  Globe, 
  Smartphone, 
  Zap, 
  Search,
  CheckCircle,
  ArrowRight,
  Code,
  Palette,
  Shield,
  TrendingUp
} from 'lucide-react';

const WebDevelopment = () => {
  const location = useLocation();

  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  const features = [
    {
      icon: Smartphone,
      title: 'Responsive Design',
      description: 'Websites that look and work perfectly on all devices - desktop, tablet, and mobile. Your users get a consistent experience regardless of how they access your site.',
      color: 'from-blue-500 to-blue-600'
    },
    {
      icon: Search,
      title: 'SEO Optimized',
      description: 'Built with search engine optimization in mind from the ground up. Clean code, fast loading times, and proper structure help your site rank higher in search results.',
      color: 'from-green-500 to-green-600'
    },
    {
      icon: Zap,
      title: 'Fast Loading',
      description: 'Optimized for speed with modern techniques like code splitting, image optimization, and efficient caching strategies to ensure lightning-fast page loads.',
      color: 'from-yellow-500 to-orange-500'
    },
    {
      icon: Globe,
      title: 'Cross-browser Compatible',
      description: 'Thoroughly tested across all major browsers including Chrome, Firefox, Safari, and Edge to ensure consistent functionality and appearance.',
      color: 'from-purple-500 to-purple-600'
    }
  ];

  const technologies = [
    { name: 'React', category: 'Frontend' },
    { name: 'Next.js', category: 'Framework' },
    { name: 'TypeScript', category: 'Language' },
    { name: 'Node.js', category: 'Backend' },
    { name: 'Tailwind CSS', category: 'Styling' },
    { name: 'PostgreSQL', category: 'Database' }
  ];

  const benefits = [
    {
      icon: Code,
      title: 'Modern Technologies',
      description: 'Built with the latest web technologies and frameworks for future-proof solutions'
    },
    {
      icon: Palette,
      title: 'Custom Design',
      description: 'Unique designs tailored to your brand identity and business requirements'
    },
    {
      icon: Shield,
      title: 'Secure & Reliable',
      description: 'Industry-standard security practices and reliable hosting solutions'
    },
    {
      icon: TrendingUp,
      title: 'Scalable Solutions',
      description: 'Built to grow with your business and handle increasing traffic and features'
    }
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6">
            <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-semibold">
              <Globe className="h-4 w-4" />
              <span>Professional Web Development</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6">Web Development Services</h1>
            <p className="text-xl text-blue-100 max-w-4xl mx-auto leading-relaxed">
              Custom websites and web applications built with cutting-edge technologies for optimal performance and user experience.
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div className="space-y-6">
              <h2 className="text-4xl font-bold text-gray-900">
                Why Choose Our Web Development Services?
              </h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  In today's digital landscape, your website is often the first impression customers have of your business. 
                  We create stunning, high-performance websites that not only look great but also drive results.
                </p>
                <p>
                  Our team of expert developers uses the latest technologies and best practices to build websites that 
                  are fast, secure, and optimized for search engines. Whether you need a simple business website or 
                  a complex web application, we have the expertise to bring your vision to life.
                </p>
                <p className="font-semibold text-gray-900">
                  We deliver websites that combine beautiful design with powerful functionality to help your business succeed online.
                </p>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="Web Development Services" 
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-600/20 to-transparent rounded-2xl"></div>
            </div>
          </div>

          {/* Benefits Section */}
          <div className="mb-20">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Key Benefits</h3>
              <p className="text-xl text-gray-600">
                Our web development approach ensures your website delivers exceptional results
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {benefits.map((benefit, index) => {
                const IconComponent = benefit.icon;
                return (
                  <div key={index} className="text-center p-6 bg-slate-50 rounded-xl hover:shadow-lg transition-shadow">
                    <div className="h-16 w-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="h-8 w-8 text-white" />
                    </div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">{benefit.title}</h4>
                    <p className="text-gray-600">{benefit.description}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Features Section */}
          <div className="mb-20">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Our Web Development Features</h3>
              <p className="text-xl text-gray-600">
                Every website we build includes these essential features for optimal performance
              </p>
            </div>

            <div className="space-y-8">
              {features.map((feature, index) => {
                const IconComponent = feature.icon;
                return (
                  <div key={index} className="bg-white border border-gray-200 rounded-2xl p-8 hover:shadow-xl transition-all duration-300">
                    <div className="flex items-start space-x-6">
                      <div className={`h-16 w-16 bg-gradient-to-br ${feature.color} rounded-2xl flex items-center justify-center flex-shrink-0`}>
                        <IconComponent className="h-8 w-8 text-white" />
                      </div>
                      
                      <div className="flex-1 space-y-4">
                        <h4 className="text-2xl font-bold text-gray-900">{feature.title}</h4>
                        <p className="text-gray-600 leading-relaxed text-lg">
                          {feature.description}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Technologies Section */}
          <div className="mb-20">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Technologies We Use</h3>
              <p className="text-xl text-gray-600">
                We leverage modern technologies to build robust and scalable web solutions
              </p>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {technologies.map((tech, index) => (
                <div key={index} className="text-center p-4 bg-slate-50 rounded-xl hover:shadow-md transition-shadow">
                  <div className="text-lg font-bold text-gray-900 mb-1">{tech.name}</div>
                  <div className="text-sm text-gray-600">{tech.category}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-8">
            <h3 className="text-4xl font-bold text-white">
              Ready to Build Your Dream Website?
            </h3>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Let our expert web developers create a stunning, high-performance website that drives results for your business.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-white text-blue-600 px-8 py-4 rounded-full font-semibold hover:bg-blue-50 transition-colors flex items-center justify-center space-x-2">
                <span>Start Your Project</span>
                <ArrowRight className="h-5 w-5" />
              </button>
              <button className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition-colors">
                View Our Portfolio
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default WebDevelopment;